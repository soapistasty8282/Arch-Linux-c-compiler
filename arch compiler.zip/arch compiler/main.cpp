
#include <windows.h>
#include <iostream>
#include <filesystem>
#include <string>
#include <algorithm>

namespace fs = std::filesystem;
using namespace std;

bool IsSuspicious(const fs::path& file)
{
    string ext = file.extension().string();

    transform(ext.begin(), ext.end(), ext.begin(),
        [](unsigned char c) { return (char)tolower(c); });

    // Heuristic only: extensions do not prove a file is malicious.
    return ext == ".scr" ||
        ext == ".pif" ||
        ext == ".vbs" ||
        ext == ".js" ||
        ext == ".hta" ||
        ext == ".ps1";
}

int main()
{
    SetConsoleTitleA("C++ Antivirus Scanner");

    cout << "====================================\n";
    cout << "       C++ ANTIVIRUS SCANNER\n";
    cout << "====================================\n\n";

    string folder;
    cout << "Enter folder path to scan: ";
    getline(cin, folder);

    if (!fs::exists(folder) || !fs::is_directory(folder))
    {
        cout << "\n[ERROR] Folder does not exist.\n";
        system("pause");
        return 1;
    }

    int scanned = 0;
    int suspicious = 0;

    cout << "\nScanning files...\n\n";

    try
    {
        for (const auto& entry :
            fs::recursive_directory_iterator(
                folder,
                fs::directory_options::skip_permission_denied))
        {
            if (!entry.is_regular_file())
                continue;

            ++scanned;

            if (IsSuspicious(entry.path()))
            {
                ++suspicious;
                cout << "[WARNING] Suspicious extension: "
                    << entry.path().string() << '\n';
            }
        }
    }
    catch (const fs::filesystem_error&)
    {
        cout << "[INFO] Some folders could not be accessed.\n";
    }

    cout << "\n====================================\n";
    cout << "Scan complete!\n";
    cout << "Files scanned: " << scanned << '\n';
    cout << "Warnings:      " << suspicious << '\n';
    cout << "====================================\n";
    cout << "No files were deleted or modified.\n";

    system("pause");
    return 0;
}